package md.localtranscript

object Resampler {
    fun linear(input: FloatArray, inputRate: Int, outputRate: Int): FloatArray {
        require(inputRate > 0 && outputRate > 0)
        if (input.isEmpty() || inputRate == outputRate) return input
        val outSize = ((input.size.toLong() * outputRate) / inputRate).toInt().coerceAtLeast(1)
        val out = FloatArray(outSize)
        val ratio = inputRate.toDouble() / outputRate.toDouble()
        for (i in out.indices) {
            val pos = i * ratio
            val left = pos.toInt().coerceIn(0, input.lastIndex)
            val right = (left + 1).coerceAtMost(input.lastIndex)
            val frac = (pos - left).toFloat()
            out[i] = input[left] * (1f - frac) + input[right] * frac
        }
        return out
    }
}
