package md.localtranscript

enum class LanguageMode(val label: String, val whisperCode: String) {
    MIXED("Română MD + rusisme / Русский (automat)", ""),
    ROMANIAN_MD("Română (Republica Moldova)", "ro"),
    RUSSIAN("Русский", "ru")
}

data class TranscriptSegment(
    val start: Float,
    val end: Float,
    val speaker: Int,
    val language: String,
    val text: String
)
