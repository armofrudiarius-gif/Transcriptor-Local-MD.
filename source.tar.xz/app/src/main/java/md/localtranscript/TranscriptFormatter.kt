package md.localtranscript

import java.util.Locale

object TranscriptFormatter {
    private fun t(sec: Float): String {
        val total = sec.coerceAtLeast(0f).toInt()
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }

    fun format(items: List<TranscriptSegment>): String = buildString {
        items.sortedBy { it.start }.forEach { seg ->
            val lang = when (seg.language.lowercase()) {
                "ro" -> "RO"
                "ru" -> "RU"
                else -> "RO/RU"
            }
            append("[").append(t(seg.start)).append("–").append(t(seg.end)).append("] ")
            append("Vorbitor ").append(seg.speaker).append(" [").append(lang).append("]: ")
            append(seg.text).append('\n')
        }
    }.trim()
}
