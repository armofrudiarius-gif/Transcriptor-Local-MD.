package md.localtranscript

data class AudioData(val samples: FloatArray, val sampleRate: Int) {
    val durationSeconds: Float get() = if (sampleRate > 0) samples.size.toFloat() / sampleRate else 0f
}
