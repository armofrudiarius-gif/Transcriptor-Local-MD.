package md.localtranscript

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    companion object {
        private const val REQ_PICK_AUDIO = 1001
        private const val REQ_CREATE_TXT = 1002
        private const val REQ_MIC = 1003
    }

    private val worker = Executors.newSingleThreadExecutor()
    private var selectedAudioUri: Uri? = null
    private var recorder: MediaRecorder? = null
    private var recordingFile: File? = null
    private var pendingSaveText: String = ""

    private lateinit var fileLabel: TextView
    private lateinit var statusLabel: TextView
    private lateinit var progress: ProgressBar
    private lateinit var languageSpinner: Spinner
    private lateinit var speakerSpinner: Spinner
    private lateinit var transcript: EditText
    private lateinit var transcribeButton: Button
    private lateinit var recordButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    override fun onDestroy() {
        runCatching { recorder?.stop() }
        recorder?.release()
        recorder = null
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun buildUi(): View {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "Transcriptor Local MD"
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Română (Republica Moldova) + rusisme / Русский • 100% local"
            textSize = 14f
            setPadding(0, dp(4), 0, dp(16))
        })

        root.addView(sectionTitle("Fișier audio"))
        fileLabel = TextView(this).apply {
            text = "Niciun fișier selectat"
            setPadding(0, dp(4), 0, dp(8))
        }
        root.addView(fileLabel)

        root.addView(Button(this).apply {
            text = "Alege fișier audio local"
            setOnClickListener { chooseAudioFile() }
        })

        recordButton = Button(this).apply {
            text = "Înregistrează audio"
            setOnClickListener {
                if (recorder == null) requestOrStartRecording() else stopRecording()
            }
        }
        root.addView(recordButton)

        root.addView(sectionTitle("Limbă"))
        languageSpinner = Spinner(this)
        languageSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            LanguageMode.entries.map { it.label }
        )
        languageSpinner.setSelection(LanguageMode.MIXED.ordinal)
        root.addView(languageSpinner)

        root.addView(sectionTitle("Număr de vorbitori"))
        speakerSpinner = Spinner(this)
        val speakerOptions = listOf("Automat") + (1..8).map { it.toString() }
        speakerSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            speakerOptions
        )
        root.addView(speakerSpinner)

        transcribeButton = Button(this).apply {
            text = "Transcrie local"
            setOnClickListener { startTranscription() }
        }
        root.addView(transcribeButton)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            dp(14)
        ).apply { topMargin = dp(12) })

        statusLabel = TextView(this).apply {
            text = "Datele nu părăsesc telefonul. Aplicația nu solicită permisiune INTERNET."
            setPadding(0, dp(8), 0, dp(12))
        }
        root.addView(statusLabel)

        root.addView(sectionTitle("Transcriere cronologică"))
        transcript = EditText(this).apply {
            minLines = 12
            gravity = Gravity.TOP or Gravity.START
            setTextIsSelectable(true)
            hint = "[00:00–00:05] Vorbitor 1 [RO]: …\n[00:05–00:09] Vorbitor 2 [RU]: …"
        }
        root.addView(transcript, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        actions.addView(Button(this).apply {
            text = "Copiază"
            setOnClickListener { copyTranscript() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        actions.addView(Button(this).apply {
            text = "Salvează TXT"
            setOnClickListener { saveTranscript() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(actions)

        root.addView(TextView(this).apply {
            text = "Confidențialitate: fără cont, fără cloud, fără telemetrie, fără acces la rețea. Fișierele sunt deschise numai la alegerea explicită a utilizatorului."
            textSize = 12f
            setPadding(0, dp(16), 0, 0)
        })

        return scroll
    }

    private fun sectionTitle(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 16f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(14), 0, dp(4))
    }

    private fun chooseAudioFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQ_PICK_AUDIO)
    }

    private fun requestOrStartRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startRecording()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
        }
    }

    private fun startRecording() {
        try {
            val dir = getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: filesDir
            if (!dir.exists()) dir.mkdirs()
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val file = File(dir, "inregistrare_$stamp.m4a")
            val mr = MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44_100)
                setAudioEncodingBitRate(128_000)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
            recordingFile = file
            recorder = mr
            recordButton.text = "Oprește înregistrarea"
            statusLabel.text = "Înregistrare locală în curs…"
        } catch (e: Exception) {
            recorder?.release()
            recorder = null
            recordingFile = null
            showError("Înregistrarea nu a putut porni", e)
        }
    }

    private fun stopRecording() {
        val mr = recorder ?: return
        try {
            mr.stop()
            val file = recordingFile ?: error("Fișier de înregistrare lipsă")
            selectedAudioUri = Uri.fromFile(file)
            fileLabel.text = file.name
            statusLabel.text = "Înregistrarea a fost salvată local și este gata pentru transcriere."
        } catch (e: Exception) {
            showError("Înregistrarea nu a putut fi salvată", e)
        } finally {
            mr.release()
            recorder = null
            recordButton.text = "Înregistrează audio"
        }
    }

    private fun startTranscription() {
        val uri = selectedAudioUri
        if (uri == null) {
            Toast.makeText(this, "Alege sau înregistrează mai întâi un fișier audio.", Toast.LENGTH_LONG).show()
            return
        }
        if (recorder != null) {
            Toast.makeText(this, "Oprește înregistrarea înainte de transcriere.", Toast.LENGTH_LONG).show()
            return
        }

        val mode = LanguageMode.entries[languageSpinner.selectedItemPosition]
        val speakers = speakerSpinner.selectedItemPosition.let { if (it == 0) null else it }

        transcribeButton.isEnabled = false
        progress.visibility = View.VISIBLE
        progress.progress = 0
        transcript.setText("")
        statusLabel.text = "Decodare audio locală…"

        worker.execute {
            try {
                val audio = AudioDecoder.decode(this, uri)
                runOnUiThread {
                    statusLabel.text = "Audio: %.1f secunde • %d Hz".format(Locale.US, audio.durationSeconds, audio.sampleRate)
                    progress.progress = 1
                }
                val engine = OfflineTranscriber(assets)
                val segments = engine.transcribe(audio, mode, speakers) { p, s ->
                    runOnUiThread {
                        progress.progress = p
                        statusLabel.text = s
                    }
                }
                val text = TranscriptFormatter.format(segments)
                runOnUiThread {
                    transcript.setText(if (text.isBlank()) "Nu a fost detectată vorbire inteligibilă." else text)
                    statusLabel.text = "Finalizat local • ${segments.map { it.speaker }.distinct().size} vorbitor(i) detectat(ți)."
                    progress.progress = 100
                }
            } catch (e: Exception) {
                runOnUiThread { showError("Transcrierea a eșuat", e) }
            } finally {
                runOnUiThread {
                    transcribeButton.isEnabled = true
                    if (progress.progress < 100) progress.visibility = View.GONE
                }
            }
        }
    }

    private fun copyTranscript() {
        val text = transcript.text?.toString().orEmpty()
        if (text.isBlank()) return
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Transcriere", text))
        Toast.makeText(this, "Text copiat.", Toast.LENGTH_SHORT).show()
    }

    private fun saveTranscript() {
        val text = transcript.text?.toString().orEmpty()
        if (text.isBlank()) {
            Toast.makeText(this, "Nu există text de salvat.", Toast.LENGTH_SHORT).show()
            return
        }
        pendingSaveText = text
        val name = "transcriere_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt"
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, name)
        }
        startActivityForResult(intent, REQ_CREATE_TXT)
    }

    @Deprecated("Deprecated in Android API, retained for minSdk compatibility without AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            REQ_PICK_AUDIO -> {
                val uri = data?.data ?: return
                val flags = data.flags and
                    (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                runCatching { contentResolver.takePersistableUriPermission(uri, flags) }
                selectedAudioUri = uri
                fileLabel.text = getDisplayName(uri)
                statusLabel.text = "Fișier local selectat. Nu este încărcat nicăieri."
            }
            REQ_CREATE_TXT -> {
                val uri = data?.data ?: return
                try {
                    contentResolver.openOutputStream(uri, "w")?.use {
                        it.write(pendingSaveText.toByteArray(StandardCharsets.UTF_8))
                    } ?: error("Nu poate fi deschis fișierul de ieșire")
                    Toast.makeText(this, "TXT salvat.", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    showError("TXT nu a putut fi salvat", e)
                }
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startRecording()
            else Toast.makeText(this, "Permisiunea microfon este necesară numai pentru înregistrare.", Toast.LENGTH_LONG).show()
        }
    }

    private fun getDisplayName(uri: Uri): String {
        if (uri.scheme == "file") return File(uri.path.orEmpty()).name
        return runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull() ?: "Fișier audio selectat"
    }

    private fun showError(prefix: String, error: Throwable) {
        progress.visibility = View.GONE
        statusLabel.text = "$prefix: ${error.message ?: error.javaClass.simpleName}"
        Toast.makeText(this, statusLabel.text, Toast.LENGTH_LONG).show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
