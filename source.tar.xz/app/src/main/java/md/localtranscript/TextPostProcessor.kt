package md.localtranscript

object TextPostProcessor {
    /**
     * Nu înlocuiește rusismele și nu "românizează" cuvintele rusești.
     * Face numai curățare tipografică, pentru a păstra cât mai fidel vorbirea reală.
     */
    fun clean(raw: String): String {
        return raw
            .replace(Regex("\\s+"), " ")
            .replace(Regex("\\s+([,.!?;:])"), "$1")
            .trim()
    }
}
