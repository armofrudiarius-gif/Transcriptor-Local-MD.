package md.localtranscript

import android.content.res.AssetManager
import com.k2fsa.sherpa.onnx.FastClusteringConfig
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineSpeakerDiarization
import com.k2fsa.sherpa.onnx.OfflineSpeakerDiarizationConfig
import com.k2fsa.sherpa.onnx.OfflineSpeakerDiarizationSegment
import com.k2fsa.sherpa.onnx.OfflineSpeakerSegmentationModelConfig
import com.k2fsa.sherpa.onnx.OfflineSpeakerSegmentationPyannoteModelConfig
import com.k2fsa.sherpa.onnx.OfflineWhisperModelConfig
import com.k2fsa.sherpa.onnx.SpeakerEmbeddingExtractorConfig
import kotlin.math.max
import kotlin.math.min

class OfflineTranscriber(private val assets: AssetManager) {
    companion object {
        private const val WHISPER_ENCODER = "models/whisper/base-encoder.int8.onnx"
        private const val WHISPER_DECODER = "models/whisper/base-decoder.int8.onnx"
        private const val WHISPER_TOKENS = "models/whisper/base-tokens.txt"
        private const val SEGMENTATION = "models/diarization/segmentation.onnx"
        private const val EMBEDDING = "models/diarization/embedding.onnx"
    }

    /**
     * expectedSpeakers = null means automatic clustering; otherwise the selected exact speaker count is used.
     */
    fun transcribe(
        audio: AudioData,
        languageMode: LanguageMode,
        expectedSpeakers: Int?,
        onProgress: (Int, String) -> Unit
    ): List<TranscriptSegment> {
        validateAssets()
        onProgress(2, "Pregătire audio locală…")

        val diarizer = createDiarizer(expectedSpeakers)
        try {
            val targetRate = diarizer.sampleRate()
            val mono16k = Resampler.linear(audio.samples, audio.sampleRate, targetRate)
            onProgress(5, "Separarea vorbitorilor…")

            val rawSegments = diarizer.processWithCallback(mono16k, callback = { done, total, _ ->
                val p = if (total <= 0) 25 else 5 + ((done.toDouble() / total) * 35).toInt()
                onProgress(p.coerceIn(5, 40), "Separarea vorbitorilor… $done/$total")
                0
            }).toList()

            val diarized = splitLongSegments(normalizeAndMergeSegments(
                if (rawSegments.isEmpty()) {
                    listOf(OfflineSpeakerDiarizationSegment(0f, mono16k.size.toFloat() / targetRate, 0))
                } else rawSegments,
                mono16k.size.toFloat() / targetRate
            ))

            val recognizer = createRecognizer(languageMode)
            try {
                val speakerMap = linkedMapOf<Int, Int>()
                val result = ArrayList<TranscriptSegment>(diarized.size)
                diarized.forEachIndexed { index, seg ->
                    val speakerNumber = speakerMap.getOrPut(seg.speaker) { speakerMap.size + 1 }
                    val pad = 0.12f
                    val start = max(0f, seg.start - pad)
                    val end = min(mono16k.size.toFloat() / targetRate, seg.end + pad)
                    val from = (start * targetRate).toInt().coerceIn(0, mono16k.size)
                    val to = (end * targetRate).toInt().coerceIn(from, mono16k.size)
                    if (to - from < targetRate / 5) return@forEachIndexed

                    val chunk = mono16k.copyOfRange(from, to)
                    val stream = recognizer.createStream()
                    try {
                        stream.acceptWaveform(chunk, targetRate)
                        recognizer.decode(stream)
                        val rr = recognizer.getResult(stream)
                        val cleaned = TextPostProcessor.clean(rr.text)
                        if (cleaned.isNotBlank()) {
                            val lang = when (languageMode) {
                                LanguageMode.ROMANIAN_MD -> "ro"
                                LanguageMode.RUSSIAN -> "ru"
                                LanguageMode.MIXED -> rr.lang.ifBlank { "ro/ru" }
                            }
                            result += TranscriptSegment(
                                start = seg.start,
                                end = seg.end,
                                speaker = speakerNumber,
                                language = lang,
                                text = cleaned
                            )
                        }
                    } finally {
                        stream.release()
                    }
                    val p = 42 + (((index + 1).toDouble() / diarized.size.coerceAtLeast(1)) * 57).toInt()
                    onProgress(p.coerceAtMost(99), "Transcriere locală ${index + 1}/${diarized.size}…")
                }
                onProgress(100, "Transcriere finalizată local.")
                return result.sortedBy { it.start }
            } finally {
                recognizer.release()
            }
        } finally {
            diarizer.release()
        }
    }

    private fun createDiarizer(expectedSpeakers: Int?): OfflineSpeakerDiarization {
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
        val config = OfflineSpeakerDiarizationConfig(
            segmentation = OfflineSpeakerSegmentationModelConfig(
                pyannote = OfflineSpeakerSegmentationPyannoteModelConfig(
                    model = SEGMENTATION,
                    windowShiftRatio = 0.1f
                ),
                numThreads = threads,
                debug = false,
                provider = "cpu"
            ),
            embedding = SpeakerEmbeddingExtractorConfig(
                model = EMBEDDING,
                numThreads = threads,
                debug = false,
                provider = "cpu"
            ),
            clustering = FastClusteringConfig(
                numClusters = expectedSpeakers ?: -1,
                threshold = 0.5f
            ),
            minDurationOn = 0.2f,
            minDurationOff = 0.5f
        )
        return OfflineSpeakerDiarization(assetManager = assets, config = config)
    }

    private fun createRecognizer(mode: LanguageMode): OfflineRecognizer {
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
        val config = OfflineRecognizerConfig(
            featConfig = FeatureConfig(sampleRate = 16_000, featureDim = 80, dither = 0f),
            modelConfig = OfflineModelConfig(
                whisper = OfflineWhisperModelConfig(
                    encoder = WHISPER_ENCODER,
                    decoder = WHISPER_DECODER,
                    language = mode.whisperCode,
                    task = "transcribe",
                    tailPaddings = 300,
                    enableTokenTimestamps = false,
                    enableSegmentTimestamps = false
                ),
                numThreads = threads,
                debug = false,
                provider = "cpu",
                modelType = "whisper",
                tokens = WHISPER_TOKENS
            ),
            decodingMethod = "greedy_search"
        )
        return OfflineRecognizer(assetManager = assets, config = config)
    }

    private fun normalizeAndMergeSegments(
        input: List<OfflineSpeakerDiarizationSegment>,
        duration: Float
    ): List<OfflineSpeakerDiarizationSegment> {
        val clean = input
            .map {
                OfflineSpeakerDiarizationSegment(
                    start = it.start.coerceIn(0f, duration),
                    end = it.end.coerceIn(0f, duration),
                    speaker = it.speaker
                )
            }
            .filter { it.end > it.start }
            .sortedWith(compareBy<OfflineSpeakerDiarizationSegment> { it.start }.thenBy { it.end })

        if (clean.isEmpty()) return emptyList()
        val out = ArrayList<OfflineSpeakerDiarizationSegment>()
        for (seg in clean) {
            val prev = out.lastOrNull()
            if (prev != null && prev.speaker == seg.speaker && seg.start - prev.end <= 0.20f) {
                out[out.lastIndex] = OfflineSpeakerDiarizationSegment(
                    start = prev.start,
                    end = max(prev.end, seg.end),
                    speaker = prev.speaker
                )
            } else {
                out += seg
            }
        }
        return out
    }

    private fun splitLongSegments(
        input: List<OfflineSpeakerDiarizationSegment>,
        maxSeconds: Float = 28f
    ): List<OfflineSpeakerDiarizationSegment> {
        val out = ArrayList<OfflineSpeakerDiarizationSegment>()
        for (seg in input) {
            var start = seg.start
            while (seg.end - start > maxSeconds) {
                out += OfflineSpeakerDiarizationSegment(start, start + maxSeconds, seg.speaker)
                start += maxSeconds
            }
            if (seg.end > start) out += OfflineSpeakerDiarizationSegment(start, seg.end, seg.speaker)
        }
        return out
    }

    private fun validateAssets() {
        listOf(WHISPER_ENCODER, WHISPER_DECODER, WHISPER_TOKENS, SEGMENTATION, EMBEDDING).forEach { path ->
            assets.open(path, AssetManager.ACCESS_STREAMING).use { input ->
                require(input.read() >= 0) { "Model local lipsă: $path" }
            }
        }
    }
}
