package md.localtranscript

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.ceil
import kotlin.math.floor

/**
 * Decodes an explicitly selected local audio URI using Android MediaCodec and downsamples
 * incrementally to mono 16 kHz, so long recordings do not require a full 44.1/48 kHz PCM copy.
 */
object AudioDecoder {
    private const val TIMEOUT_US = 10_000L
    private const val TARGET_RATE = 16_000

    fun decode(context: Context, uri: Uri): AudioData {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, uri, null)
            var audioTrack = -1
            var selectedFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    audioTrack = i
                    selectedFormat = f
                    break
                }
            }
            require(audioTrack >= 0 && selectedFormat != null) {
                "Fișierul nu conține o pistă audio compatibilă."
            }
            val inputFormat = requireNotNull(selectedFormat)
            extractor.selectTrack(audioTrack)

            val mime = inputFormat.getString(MediaFormat.KEY_MIME)
                ?: error("Tip audio necunoscut")
            val codec = MediaCodec.createDecoderByType(mime)
            try {
                codec.configure(inputFormat, null, null, 0)
                codec.start()
                return decodeLoop(extractor, codec, inputFormat)
            } finally {
                runCatching { codec.stop() }
                codec.release()
            }
        } finally {
            extractor.release()
        }
    }

    private fun decodeLoop(
        extractor: MediaExtractor,
        codec: MediaCodec,
        initialFormat: MediaFormat
    ): AudioData {
        var inputEnded = false
        var outputEnded = false
        var outputSampleRate = initialFormat.intOr(MediaFormat.KEY_SAMPLE_RATE, TARGET_RATE)
        var outputChannels = initialFormat.intOr(MediaFormat.KEY_CHANNEL_COUNT, 1).coerceAtLeast(1)
        var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT

        val expectedDurationUs = initialFormat.longOr(MediaFormat.KEY_DURATION, 0L)
        val expectedSamples = if (expectedDurationUs > 0) {
            ((expectedDurationUs / 1_000_000.0) * TARGET_RATE).toInt().coerceAtLeast(16_000)
        } else 16_000 * 60
        val output = FloatArrayBuilder(expectedSamples)
        var resampler = StreamingLinearResampler(outputSampleRate, TARGET_RATE, output)
        val info = MediaCodec.BufferInfo()

        while (!outputEnded) {
            if (!inputEnded) {
                val inputIndex = codec.dequeueInputBuffer(TIMEOUT_US)
                if (inputIndex >= 0) {
                    val input = codec.getInputBuffer(inputIndex)
                        ?: error("Nu poate fi accesat bufferul audio de intrare")
                    input.clear()
                    val sampleSize = extractor.readSampleData(input, 0)
                    if (sampleSize < 0) {
                        codec.queueInputBuffer(
                            inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                        )
                        inputEnded = true
                    } else {
                        codec.queueInputBuffer(
                            inputIndex, 0, sampleSize, extractor.sampleTime.coerceAtLeast(0L), 0
                        )
                        extractor.advance()
                    }
                }
            }

            when (val outputIndex = codec.dequeueOutputBuffer(info, TIMEOUT_US)) {
                MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    val f = codec.outputFormat
                    val newRate = f.intOr(MediaFormat.KEY_SAMPLE_RATE, outputSampleRate)
                    outputChannels = f.intOr(MediaFormat.KEY_CHANNEL_COUNT, outputChannels).coerceAtLeast(1)
                    pcmEncoding = if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                        f.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    } else AudioFormat.ENCODING_PCM_16BIT
                    if (newRate != outputSampleRate && output.size == 0) {
                        outputSampleRate = newRate
                        resampler = StreamingLinearResampler(outputSampleRate, TARGET_RATE, output)
                    }
                }
                MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> Unit
                else -> if (outputIndex >= 0) {
                    val out = codec.getOutputBuffer(outputIndex)
                    if (out != null && info.size > 0) {
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        out.order(ByteOrder.LITTLE_ENDIAN)
                        val mono = pcmToMono(out, outputChannels, pcmEncoding)
                        resampler.accept(mono)
                    }
                    outputEnded = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    codec.releaseOutputBuffer(outputIndex, false)
                }
            }
        }

        val samples = output.finish()
        require(samples.isNotEmpty()) { "Nu au putut fi decodate eșantioane audio." }
        return AudioData(samples, TARGET_RATE)
    }

    private fun pcmToMono(buffer: ByteBuffer, channels: Int, encoding: Int): FloatArray {
        val bytesPerSample = when (encoding) {
            AudioFormat.ENCODING_PCM_FLOAT -> 4
            AudioFormat.ENCODING_PCM_8BIT -> 1
            else -> 2
        }
        val frames = buffer.remaining() / (bytesPerSample * channels)
        val out = FloatArray(frames)
        for (frame in 0 until frames) {
            var sum = 0f
            repeat(channels) {
                sum += when (encoding) {
                    AudioFormat.ENCODING_PCM_FLOAT -> buffer.float
                    AudioFormat.ENCODING_PCM_8BIT -> ((buffer.get().toInt() and 0xff) - 128) / 128f
                    else -> buffer.short / 32768f
                }
            }
            out[frame] = (sum / channels).coerceIn(-1f, 1f)
        }
        return out
    }

    private class StreamingLinearResampler(
        inputRate: Int,
        outputRate: Int,
        private val output: FloatArrayBuilder
    ) {
        private val step = inputRate.toDouble() / outputRate.toDouble()
        private var processedFrames = 0L
        private var nextSourcePosition = 0.0
        private var previous: Float? = null

        fun accept(chunk: FloatArray) {
            if (chunk.isEmpty()) return
            val start = processedFrames
            val end = start + chunk.lastIndex
            while (ceil(nextSourcePosition).toLong() <= end) {
                val leftIndex = floor(nextSourcePosition).toLong()
                val rightIndex = ceil(nextSourcePosition).toLong()
                val left = valueAt(leftIndex, start, chunk)
                val right = valueAt(rightIndex, start, chunk)
                if (left == null || right == null) break
                val frac = (nextSourcePosition - leftIndex).toFloat()
                output.add((left * (1f - frac) + right * frac).coerceIn(-1f, 1f))
                nextSourcePosition += step
            }
            previous = chunk.last()
            processedFrames += chunk.size
        }

        private fun valueAt(index: Long, start: Long, chunk: FloatArray): Float? {
            if (index == start - 1) return previous
            val local = (index - start).toInt()
            return chunk.getOrNull(local)
        }
    }

    private class FloatArrayBuilder(initialCapacity: Int) {
        private var data = FloatArray(initialCapacity.coerceIn(16_000, 16_000 * 60 * 60 * 4))
        var size: Int = 0
            private set

        fun add(value: Float) {
            if (size == data.size) {
                val next = (data.size + data.size / 2).coerceAtLeast(data.size + 16_000)
                data = data.copyOf(next)
            }
            data[size++] = value
        }

        fun finish(): FloatArray = when {
            size == data.size -> data
            size == 0 -> FloatArray(0)
            else -> data.copyOf(size)
        }
    }

    private fun MediaFormat.intOr(key: String, default: Int): Int =
        if (containsKey(key)) getInteger(key) else default

    private fun MediaFormat.longOr(key: String, default: Long): Long =
        if (containsKey(key)) getLong(key) else default
}
